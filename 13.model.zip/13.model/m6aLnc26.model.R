


#���ð�
library(survival)
library(caret)
library(glmnet)
library(survminer)
library(timeROC)
setwd("E:\\��������\\26.model")      #���ù���Ŀ¼
rt=read.table("uniSigExp.txt", header=T, sep="\t", check.names=F, row.names=1)     #��ȡ�����ļ�
rt$futime[rt$futime<=0]=0.003

#�Է������ѭ�����ҳ�train��test�������ķ���
for(i in 1:1000){
	#############�����ݽ��з���#############
	inTrain<-createDataPartition(y=rt[,3], p=0.7, list=F)
	train<-rt[inTrain,]
	test<-rt[-inTrain,]
	trainOut=cbind(id=row.names(train), train)
	testOut=cbind(id=row.names(test), test)

	#lasso�ع�
	x=as.matrix(train[,c(3:ncol(train))])
	y=data.matrix(Surv(train$futime,train$fustat))
	fit <- glmnet(x, y, family = "cox", maxit = 1000)
	cvfit <- cv.glmnet(x, y, family="cox", maxit = 1000)
	coef <- coef(fit, s = cvfit$lambda.min)
	index <- which(coef != 0)
	actCoef <- coef[index]
	lassoGene=row.names(coef)[index]
	geneCoef=cbind(Gene=lassoGene, Coef=actCoef)
	if(nrow(geneCoef)<2){next}
	
	#���train�����ֵ
	trainFinalGeneExp=train[,lassoGene]
	#myFun=function(x){crossprod(as.numeric(x), actCoef)}
	#trainScore=apply(trainFinalGeneExp, 1, myFun)
	trainScore=predict(cvfit, newx=as.matrix(train[,c(3:ncol(train))]), s="lambda.min", type="response")
	outCol=c("futime", "fustat", lassoGene)
	risk=as.vector(ifelse(trainScore>median(trainScore), "high", "low"))
	train=cbind(train[,outCol], riskScore=as.vector(trainScore), risk)
	trainRiskOut=cbind(id=rownames(train), train)

	#���test�����ֵ
	testFinalGeneExp=test[,lassoGene]
	#testScore=apply(testFinalGeneExp, 1, myFun)
	testScore=predict(cvfit, newx=as.matrix(test[,c(3:ncol(test))]), s="lambda.min", type="response")
	outCol=c("futime", "fustat", lassoGene)
	risk=as.vector(ifelse(testScore>median(trainScore), "high", "low"))
	test=cbind(test[,outCol], riskScore=as.vector(testScore), risk)
	testRiskOut=cbind(id=rownames(test), test)
	
	#�������pvalue	
	diff=survdiff(Surv(futime, fustat) ~risk, data=train)
	pValue=1-pchisq(diff$chisq, df=1)
	diffTest=survdiff(Surv(futime, fustat) ~risk, data=test)
	pValueTest=1-pchisq(diffTest$chisq, df=1)

	#ROC���������
	predictTime=1    #Ԥ��ʱ��
	roc=timeROC(T=train$futime, delta=train$fustat,
	            marker=trainScore, cause=1,
	            weighting='aalen',
	            times=c(predictTime), ROC=TRUE)
	rocTest=timeROC(T=test$futime, delta=test$fustat,
	            marker=testScore, cause=1,
	            weighting='aalen',
	            times=c(predictTime), ROC=TRUE)	
	
	if((pValue<0.01) & (roc$AUC[2]>0.7) & (pValueTest<0.05) & (rocTest$AUC[2]>0.65)){
		#���������
		write.table(trainOut,file="train.data.txt",sep="\t",quote=F,row.names=F)
		write.table(testOut,file="test.data.txt",sep="\t",quote=F,row.names=F)
		#lassoͼ��
		pdf("lambda.pdf")
		plot(fit, xvar = "lambda", label = TRUE)
		dev.off()
		pdf("cvfit.pdf")
		plot(cvfit)
		abline(v=log(c(cvfit$lambda.min,cvfit$lambda.1se)),lty="dashed")
		dev.off()
	    #���ģ�͹�ʽ�ͷ����ļ�
		write.table(geneCoef, file="geneCoef.txt", sep="\t", quote=F, row.names=F)
		write.table(trainRiskOut,file="trainRisk.txt",sep="\t",quote=F,row.names=F)
		write.table(testRiskOut,file="testRisk.txt",sep="\t",quote=F,row.names=F)
		#������Ʒ�ķ���ֵ
		allRiskOut=rbind(trainRiskOut, testRiskOut)
		write.table(allRiskOut,file="allRisk.txt",sep="\t",quote=F,row.names=F)
		break
	}
}



